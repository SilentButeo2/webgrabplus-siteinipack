# VPN Config Cleanup Script
# Removes outdated directives (block-outside-dns, <crl-verify>, etc.)
# Use if you're running OpenVPN 2.6+ and configs fail to load.
# If you're on older OpenVPN versions, you may not need this.

$folder = "C:\Path\To\Your\OvpnFiles"

Get-ChildItem -Path $folder -Filter *.ovpn | ForEach-Object {
    $content = Get-Content $_.FullName -Raw

    # Remove block-outside-dns
    $content = $content -replace '(?mi)^\s*block-outside-dns\s*$', ''

    # Remove <crl-verify> blocks
    $content = $content -replace '(?is)<crl-verify>.*?</crl-verify>', ''

    # Remove ns-cert-type
    $content = $content -replace '(?mi)^\s*ns-cert-type.*$', ''

    # Remove old cipher lines (leave data-ciphers intact)
    $content = $content -replace '(?mi)^\s*cipher\s+.*$', ''

    # Remove static/shared key mode
    $content = $content -replace '(?mi)^\s*secret\s+.*$', ''

    # Remove old compression
    $content = $content -replace '(?mi)^\s*comp-lzo.*$', ''

    # Remove obsolete tls-remote
    $content = $content -replace '(?mi)^\s*tls-remote.*$', ''

    Set-Content -Path $_.FullName -Value $content
    Write-Host "Cleaned $($_.Name)"
}
