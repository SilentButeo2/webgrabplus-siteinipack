VPN Config Cleanup Script (cleanup-ovpn.ps1)

Purpose:
This script automatically removes outdated directives from .ovpn configuration files.
It is intended for users running OpenVPN 2.6 or newer, where legacy options may cause errors.

What it removes:
- block-outside-dns (Windows-specific, no longer supported)
- <crl-verify> ... </crl-verify> inline blocks (deprecated in OpenVPN 2.6)
- ns-cert-type (replaced by remote-cert-tls server)
- cipher lines (use data-ciphers in modern configs)
- secret (static/shared key mode, deprecated)
- comp-lzo (obsolete compression option)
- tls-remote (replaced by verify-x509-name)

Usage:
1. Place the script in the same folder as your .ovpn files,
   or edit the $folder variable inside the script to point to your config directory.
2. Run the script in PowerShell:
   .\cleanup-ovpn.ps1
3. The script will overwrite the original .ovpn files with cleaned versions.
   If you want backups, add a Copy-Item step before Set-Content.

Notes:
- If you are using older OpenVPN versions (2.3/2.4), you may still need these directives.
  In that case, do not run the script.
- For OpenVPN 2.6+, removing them is safe and recommended.
- Always test a cleaned config before deploying widely.

================================================================================================

WebGrabControl
--------------
*** dotnet 8 required.
The app is hard coded for openvpn community and uses C:\Program Files\OpenVPN\bin\openvpn.exe
openvpn connect will not work as it does not support cli.

Auto Run
--------------
Run the application with the argument ---autorun
WebGrabControl.exe --autorun
The application will start minimized simulate a start button click and close when completed.

Logging
--------------
Everytime webgrab runs the current logs are saved to the log directory.
Only the last 5 logs are kept.
This is doesnt provide much information if you are running webgrab multiple times testing channels.
It added for once a stable setup is achieved and the app runs once a day on a schedule(task).
If a site stops working,ect you can easily look back at the logs and see the day the issue started(assume its within the last 5 days).

XML Tools
--------------
Configure,enable and save a profile to have xml tools run when the console app is run or when the --autorun argument is used.
File will be saved as merged.xml in the app directory.
Defaults
Run when console runs - true
Replace star rating - false

EPG Debugger
--------------
Validate - loads source.xml file from filename setting of webgrb++config.xml and webgrab++.log.txt
         - displays(color coded) any info,error,debug,warnings detected.
         - if a channel has multiple error the error with the highest severity color is used.
Compare with previous - shows differences from last run(merged.xml) and merged_prev.xml
                      - removed or added channels and program count.
Export - exports results of Compare with previous.

