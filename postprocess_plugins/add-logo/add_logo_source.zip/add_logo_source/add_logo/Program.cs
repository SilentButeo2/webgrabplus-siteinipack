﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace add_logo
{
    class Program
    {
        /*
         * This little program adds or corrects the 'src' attribute value of the <icon element 
         * in the channel section of an input xmltv file
         * That value represents the link where the channel logo is available
         */
        static void Main(string[] args)
        {
            // args 
            // /in:xmltv input file  
            // /out:xmltv output file    ** default input file
            // /logos:logos file 

            // not implemented, useful?
            // /mode:   replace or add   ** default replace
            // /log: on lists all channel logo's  ** default off
            string version = Assembly.GetExecutingAssembly().GetName().Version.ToString(3);
            Console.WriteLine("Add or change channel logos in xmltv files");
            Console.WriteLine("Version " + version + " Jan van Straaten , November 2021\n");
            string xmltv_in = "";
            string xmltv_in_path = "";
            string xmltv_out = "";
            string xmltv_out_path = "";
            string logos_file = "";
            string logos_file_path = "";
            //string mode = "replace";
            //bool log = false;
            bool fail = false;
            string message = "";
            string path;
            if (args.Length > 1) // minimum 2
            {
                foreach (string arg in args)
                {
                    if (!arg.StartsWith("/"))
                    {
                        fail = true;
                        message = "Incorrect argument " + arg + " , must start with / character";
                        break;
                    }
                    Match m = null;
                    m = Regex.Match(arg, @"/(?:in|out|logos)(?::|=)(.+)");
                    if (m.Success)
                    {
                        if (m.Groups.Count == 2)
                        {
                            if (arg.StartsWith("/in")) xmltv_in = m.Groups[1].Value;
                            else if (arg.StartsWith("/out")) xmltv_out = m.Groups[1].Value;
                            else if (arg.StartsWith("/logos")) logos_file = m.Groups[1].Value;
                        }
                        else
                        {
                            fail = true;
                            message = "Incorrect argument " + arg + " , must have a = or : character to separate argument name from its value";
                            break;
                        }
                    }
                    else
                    {
                        fail = true;
                        message = "Unknown or incomplete argument " + arg + " , must start with /in , /out or /logos and have a value";
                        break;
                    }
                }
                if (xmltv_in == "")
                {
                    fail = true;
                    message = "Missing or incorrect xmltv input file argument /in ";
                }
                if (!fail)
                {
                    // get the path where it all happens
                    path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                    if (xmltv_out == xmltv_in)
                    {
                        // prevent in and out the same
                        xmltv_out = "";
                        Console.WriteLine("Error: /out cannot be the same as /in !!");
                    }
                    // default out
                    if (xmltv_out == "")
                    {
                        xmltv_out = xmltv_in.ToLower().Replace(".xml", "_logos.xml");
                        xmltv_out_path = Path.Combine(new string[] { path, xmltv_out });
                        Console.WriteLine("Default /out will be used " + xmltv_out + "\n");
                    }
                    // path included ?
                    else
                    {
                        if (Path.GetDirectoryName(xmltv_out) != "") xmltv_out_path = xmltv_out;
                        else xmltv_out_path = Path.Combine(new string[] { path, xmltv_out });
                    }
                    xmltv_in_path = Path.Combine(new string[] { path, xmltv_in });
                    if (!File.Exists(xmltv_in_path))
                    {
                        message = "xmltv input file - " + xmltv_in + " - doesn't exist in " + path;
                        fail = true;
                    }
                    logos_file_path = Path.Combine(new string[] { path, logos_file });
                    if (!File.Exists(logos_file_path))
                    {
                        message = "logos file - " + logos_file + " - doesn't exist in " + path;
                        fail = true;
                    }
                }
            }
            else if (args.Length == 1)
            {
                string a = args[0];
                if (a == "/h" || a == "/?" || a == ".h" || a == ".?")
                {
                    // /in=guide+2.xml /out=guide+logos.xml /logos=logos.ini
                    message = @"Help text :
----------------------------------------------------------------------------------------------
**  Specify the following command line arguments:

- syntax   ... /name=value or /name:value
- required ... /in=xmltv input file name                   ... e.g. /in=guide.xml
- optional ... /out=xmltv output file name                 ... e.g. /out=epg_logos.xml
      default : the input file name with a logos addition  ... e.g.    guide_logos.xml
      ! cannot be the same as /in !!
- required ... /logos=name of the file with the new logos  ... e.g. /logos=my_logos.ini
- optional ... /h or /? as single argument to get this help

**  Example of a valid command line:
      add_logo.exe /in=guide.xml /out=epg_logos.xml /logos=logos.ini
- as webgrab+plus postprocess plugin:
      <postprocess run=\""y\"" grab=\""n\"">add_logo.exe /in=guide+2.xml /logos=logos.txt</postprocess>    

**  Content of the logos file:

- syntax  ...  channel name, logo link

- channel name must be the same as the channel_id value in the channel section of the input file
- lines starting with * are considered a comment text

**  Example logos file content:

* list of channel logo links 
*
TV Camara , https://www.net.com.br/imagens/logo/tv_camara-1680_95x39.png
TV Brasil , https://www.net.com.br/imagens/logo/tv_brasil-1683_95x39.png
PREMIERE HD 3 , https://www.net.com.br/imagens/logo/premiere_hd_3_-1175_95x39.png
----------------------------------------------------------------------------------------------
";
                }
                else message = "not enough arguments,  try /h for help";
                fail = true;
            }
            else 
            {
                fail = true;
                message = "not enough arguments,  try /h for help";
            }
            if (!fail)
            {
                // all channels in the xmltv_in (xmltv_id , icon)
                Dictionary<string, string> xmltv_channels = new Dictionary<string, string>();
                XmlNodeList xnl;

                // read xmltv_in
                XmlDocument xmltv = new XmlDocument();
                xmltv.LoadXml(File.ReadAllText(xmltv_in_path));
                xnl = xmltv.SelectNodes("tv/channel");
                foreach (XmlNode xn in xnl)
                {
                    string xmltv_id = xn.Attributes["id"].Value;
                    string icon = "";
                    XmlNode xnn = xn.SelectSingleNode("icon");
                    if (xnn != null) icon = xnn.Attributes["src"].Value;
                    // xmltv_id as key in lower case!
                    // that way avoid arbitrary difference between the xmltv_in and logos.ini
                    xmltv_channels.Add(xmltv_id.ToLower(), icon);
                }
                // read logos.ini
                //Dictionary<string, string> logos = new Dictionary<string, string>();
                string content = File.ReadAllText(logos_file_path, Encoding.UTF8);
                int logos_changed = 0;
                foreach (string line in content.Split('\n'))
                {
                    if (!line.StartsWith("*") && line != "\r")
                    {
                        string[] parts = line.Split(',');
                        string xmltv_id_ini = parts[0].Trim(); // this is the xmltv_id in the logos.ini
                        string key = xmltv_id_ini.ToLower();
                        if (parts.Length > 1)
                        {
                            string new_icon = parts[1].Trim();
                            // insert or add in xmltv_channels ?
                            if (xmltv_channels.ContainsKey(key))
                            {
                                // channel exist in xmltv_in
                                // compare logos
                                if (new_icon.ToLower() != xmltv_channels[key].ToLower())
                                {
                                    // not same
                                    logos_changed++;
                                    bool was_empty = xmltv_channels[key].ToLower() == "";
                                    //if (mode == "replace") xmltv_channels[key] = new_icon;  // mode not useful
                                    xmltv_channels[key] = new_icon;
                                    if (xmltv_id_ini.Length > 25) xmltv_id_ini = xmltv_id_ini.Substring(0, 23) + "..";
                                    Console.Write("'" + xmltv_id_ini + "'");
                                    // 30 spaces -- max length xmltv_id 25 .. is not enough !
                                    string spaces = "                              ".Substring(0, 25 - xmltv_id_ini.Length);
                                    //Console.CursorLeft = 25;  //  crashes when used as wgpostprocess plugin
                                    if (!was_empty) Console.WriteLine(spaces + "logo replaced by '" + new_icon + "'");
                                    else Console.WriteLine(spaces + "missing logo added '" + new_icon + "'");
                                }
                            }
                        }
                    }
                }
                if (logos_changed == 0) Console.WriteLine("No logos added or changed .. ");
                // write new values to xmltv 
                foreach (XmlNode xn in xnl)
                {                    
                    // replace the <icon src= attribute value by the value of xmltv_channels
                    string xmltv_id = xn.Attributes["id"].Value;
                    string icon = "";
                    XmlNode xnn = xn.SelectSingleNode("icon");
                    if (xnn != null) icon = xnn.Attributes["src"].Value;
                    // find corresponding in xmltv_channels, that contains the new value
                    string new_icon = xmltv_channels[xmltv_id.ToLower()];
                    if (icon != "") xnn.Attributes["src"].Value = new_icon;
                    else // no existing value in xmltv_in, create node <icon with attribute src
                    {
                        XmlNode xn_icon;
                        xn_icon = xmltv.CreateElement("icon");
                        XmlNode display_name = xn.SelectSingleNode("display-name");
                        xn.InsertAfter(xn_icon, display_name);
                        //xn.AppendChild(xn_icon);
                        XmlAttribute xa_scr = xmltv.CreateAttribute("src");
                        xa_scr.Value = new_icon;
                        xn_icon.Attributes.Append(xa_scr);
                    }                    
                }
                // save
                // check xmltv_out_path
                string p = Path.GetDirectoryName(xmltv_out_path);
                if (p != "" && !Directory.Exists(p))
                {
                    // create directory
                    Directory.CreateDirectory(Path.GetDirectoryName(xmltv_out_path));
                }
                XmlTextWriter xmlWriter = new XmlTextWriter(xmltv_out_path, Encoding.UTF8)
                {
                    Formatting = Formatting.Indented
                };
                xmltv.WriteTo(xmlWriter);
                xmlWriter.Close();
                Console.WriteLine("\nResults saved in " + xmltv_out_path);
                Console.WriteLine(".. done ..");              
            }
            else
            {
                Console.WriteLine(message);
            }            
        }
    }
}